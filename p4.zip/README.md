# Project 4: Roll Your Own CDN
Authors :

*Nikhil Mollay : 001020022*

*Dileep Kumar Shah : 001044150* 

## High Level Approach


## Contributions 

*Nikhil Mollay* :

*Dileep Kumar Shah* : 


## Challenges:

## Congestion Control



## How to run the code
1. Go to the directory where the code is present.
2. Run the following command to compile the code:
```
make
```
3. Run the following command to run the code:
```
sudo ./rawhttpget <URL>
```
4. To clean the directory run the following command:
```
make clean
```
5. Downloaded file will be present in the same directory as the code.

## Testing
1. 

2. 

## References
1. 


